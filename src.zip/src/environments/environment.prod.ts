export const environment = {
  production: true,
  base_url:"http://15.206.85.11:8001",
};
